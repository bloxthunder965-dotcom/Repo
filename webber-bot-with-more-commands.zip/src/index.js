require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, Collection, GatewayIntentBits, Partials } = require('discord.js');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel],
});

client.commands = new Collection();
client.inviteCache = new Map(); // guildId -> Map(code -> uses)

const commandsPath = path.join(__dirname, 'commands');
function loadCommands(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) loadCommands(full);
    else if (entry.name.endsWith('.js')) {
      const command = require(full);
      if (command.data && command.execute) {
        client.commands.set(command.data.name, command);
      }
    }
  }
}
if (fs.existsSync(commandsPath)) loadCommands(commandsPath);

const eventsPath = path.join(__dirname, 'events');
if (fs.existsSync(eventsPath)) {
  for (const file of fs.readdirSync(eventsPath).filter(f => f.endsWith('.js'))) {
    const event = require(path.join(eventsPath, file));
    if (event.once) client.once(event.name, (...args) => event.execute(...args, client));
    else client.on(event.name, (...args) => event.execute(...args, client));
  }
}

const token = process.env.DISCORD_TOKEN;
if (!token) {
  console.error('Missing DISCORD_TOKEN in environment/.env');
  process.exit(1);
}

// Gateway health logging + auto-heal: if the bot is disconnected for too long,
// exit so the watchdog restarts it into a fresh gateway session.
const { Status } = require('discord.js');
let offlineSince = null;
client.on('shardReady', (id) => { offlineSince = null; console.log(`[gateway] shard ${id} READY`); });
client.on('shardReconnecting', (id) => { console.log(`[gateway] shard ${id} reconnecting...`); });
client.on('shardResume', (id) => { offlineSince = null; console.log(`[gateway] shard ${id} resumed`); });
client.on('shardDisconnect', (event, id) => {
  offlineSince = Date.now();
  console.warn(`[gateway] shard ${id} disconnected (code ${event?.code || 'unknown'}), waiting for reconnect...`);
});
client.on('shardError', (error, id) => console.error(`[gateway] shard ${id} error:`, error.message));

setInterval(() => {
  if (client.ws.status !== Status.Ready) {
    if (!offlineSince) offlineSince = Date.now();
    console.warn(`[gateway] not READY (status ${client.ws.status}) for ${Math.round((Date.now() - offlineSince) / 1000)}s`);
    if (Date.now() - offlineSince > 90000) {
      console.error('[gateway] offline too long — restarting process');
      process.exit(1);
    }
  } else {
    offlineSince = null;
  }
}, 30000).unref();

client.login(token);
