const { SlashCommandBuilder } = require('discord.js');

const ANSWERS = [
  'It is certain.', 'It is decidedly so.', 'Without a doubt.', 'Yes, definitely.',
  'You may rely on it.', 'As I see it, yes.', 'Most likely.', 'Outlook good.',
  'Yes.', 'Signs point to yes.', 'Reply hazy, try again.', 'Ask again later.',
  'Better not tell you now.', 'Cannot predict now.', 'Concentrate and ask again.',
  "Don't count on it.", 'My reply is no.', 'My sources say no.',
  'Outlook not so good.', 'Very doubtful.',
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('8ball')
    .setDescription('Ask the magic 8-ball a question')
    .addStringOption(opt => opt.setName('question').setDescription('Your question').setMaxLength(500).setRequired(true)),
  async execute(interaction) {
    const question = interaction.options.getString('question', true);
    const answer = ANSWERS[Math.floor(Math.random() * ANSWERS.length)];
    await interaction.reply({ content: `🎱 **Question:** ${question}\n**Answer:** ${answer}`, allowedMentions: { parse: [] } });
  },
};
