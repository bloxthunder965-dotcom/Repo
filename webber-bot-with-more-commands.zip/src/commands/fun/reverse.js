const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reverse')
    .setDescription('Reverse the text you type')
    .addStringOption(opt => opt.setName('text').setDescription('Text to reverse').setMaxLength(2000).setRequired(true)),
  async execute(interaction) {
    const text = interaction.options.getString('text', true);
    const reversed = Array.from(text).reverse().join('');
    await interaction.reply({ content: reversed, allowedMentions: { parse: [] } });
  },
};
