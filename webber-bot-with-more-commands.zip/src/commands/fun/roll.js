const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('roll')
    .setDescription('Roll dice (e.g. 1d20, 2d6, d100)')
    .addStringOption(opt => opt.setName('dice').setDescription('Dice notation like 2d20 (default: 1d20)').setMaxLength(20)),
  async execute(interaction) {
    const raw = (interaction.options.getString('dice') || '1d20').trim().toLowerCase().replace(/\s+/g, '');
    let count = 1;
    let sides;

    const match = raw.match(/^(\d*)d(\d+)$/);
    if (match) {
      count = match[1] === '' ? 1 : Number(match[1]);
      sides = Number(match[2]);
    } else if (/^\d+$/.test(raw)) {
      count = 1;
      sides = Number(raw);
    }

    if (!sides || sides < 2 || sides > 1000 || count < 1 || count > 25) {
      return interaction.reply({
        content: 'Use something like `1d20`, `2d6`, or `d100` (up to 25 dice, 2–1000 sides).',
        ephemeral: true,
      });
    }

    const rolls = Array.from({ length: count }, () => Math.floor(Math.random() * sides) + 1);
    const total = rolls.reduce((a, b) => a + b, 0);
    const text = count === 1
      ? `🎲 You rolled **${total}** (d${sides}).`
      : `🎲 Rolls: ${rolls.join(', ')}\n**Total: ${total}**`;

    await interaction.reply({ content: text });
  },
};
