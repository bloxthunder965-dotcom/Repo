const { SlashCommandBuilder } = require('discord.js');

const CHOICES = {
  rock: '🪨',
  paper: '📄',
  scissors: '✂️',
};
const KEYS = Object.keys(CHOICES);
const BEATS = { rock: 'scissors', paper: 'rock', scissors: 'paper' };

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rps')
    .setDescription('Play rock, paper, scissors against the bot')
    .addStringOption(opt => opt.setName('choice')
      .setDescription('Your choice')
      .setRequired(true)
      .addChoices(
        { name: 'Rock', value: 'rock' },
        { name: 'Paper', value: 'paper' },
        { name: 'Scissors', value: 'scissors' },
      )),
  async execute(interaction) {
    const player = interaction.options.getString('choice', true);
    const bot = KEYS[Math.floor(Math.random() * KEYS.length)];
    const result = player === bot ? 'It\'s a tie!' : BEATS[player] === bot ? 'You win!' : 'I win!';

    await interaction.reply({
      content: `${CHOICES[player]} You chose **${player}**\n${CHOICES[bot]} I chose **${bot}**\n\n**${result}**`,
    });
  },
};
