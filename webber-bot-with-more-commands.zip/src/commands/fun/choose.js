const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('choose')
    .setDescription('Pick a random option from a list')
    .addStringOption(opt => opt.setName('options').setDescription('Options separated by commas or |').setMaxLength(2000).setRequired(true)),
  async execute(interaction) {
    const options = interaction.options.getString('options', true)
      .split(/[,|\n]+/)
      .map(s => s.trim())
      .filter(Boolean);

    if (options.length < 2) {
      return interaction.reply({ content: 'Give me at least 2 options, separated by commas or `|`.', ephemeral: true });
    }
    if (options.length > 25) {
      return interaction.reply({ content: 'Please give me 25 options or fewer.', ephemeral: true });
    }

    const pick = options[Math.floor(Math.random() * options.length)];
    await interaction.reply({ content: `🤔 I choose: **${pick}**`, allowedMentions: { parse: [] } });
  },
};
