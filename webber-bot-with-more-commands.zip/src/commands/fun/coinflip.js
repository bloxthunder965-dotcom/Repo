const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('coinflip')
    .setDescription('Flip a coin')
    .addIntegerOption(opt => opt.setName('flips').setDescription('Number of flips (1–25, default: 1)').setMinValue(1).setMaxValue(25)),
  async execute(interaction) {
    const flips = interaction.options.getInteger('flips') || 1;
    const results = Array.from({ length: flips }, () => (Math.random() < 0.5 ? 'Heads' : 'Tails'));
    const heads = results.filter(r => r === 'Heads').length;
    const tails = flips - heads;

    if (flips === 1) {
      return interaction.reply({ content: `🪙 It landed on **${results[0]}**!` });
    }

    await interaction.reply({
      content: `🪙 ${results.join(', ')}\n**Heads: ${heads} | Tails: ${tails}**`,
    });
  },
};
