const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getInvites } = require('../../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('invites')
    .setDescription('Check invite count for yourself or another member')
    .addUserOption(opt => opt.setName('user').setDescription('Member to check').setRequired(false)),
  async execute(interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const rec = getInvites(interaction.guild.id, user.id);
    await interaction.reply({
      content: `**${user.tag}** has **${rec.total || 0}** invites (joins: ${rec.joins || 0}, leaves: ${rec.leaves || 0}, bonus: ${rec.bonus || 0}).`,
      allowedMentions: { parse: [] },
    });
  },
};
