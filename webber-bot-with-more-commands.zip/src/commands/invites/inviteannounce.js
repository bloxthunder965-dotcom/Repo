const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder } = require('discord.js');
const { getAnnounce, setAnnounce, clearAnnounce } = require('../../utils/database');

const EXAMPLE = '🎉 {member} joined using {inviter}\'s invite! They now have {count} invite(s).';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('inviteannounce')
    .setDescription('Send a message in a channel whenever someone joins via an invite')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub =>
      sub.setName('set')
        .setDescription('Set the announcement channel and message')
        .addChannelOption(opt =>
          opt.setName('channel')
            .setDescription('Channel to post invite announcements in')
            .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
            .setRequired(true))
        .addStringOption(opt =>
          opt.setName('message')
            .setDescription('Custom message. Placeholders: {member}, {inviter}, {count}, {code}')
            .setMaxLength(1000)
            .setRequired(false)))
    .addSubcommand(sub =>
      sub.setName('disable')
        .setDescription('Disable invite announcements'))
    .addSubcommand(sub =>
      sub.setName('show')
        .setDescription('Show the current invite announcement settings')),
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'set') {
      const channel = interaction.options.getChannel('channel', true);
      const message = interaction.options.getString('message') || EXAMPLE;
      setAnnounce(interaction.guild.id, channel.id, message);

      const embed = new EmbedBuilder()
        .setTitle('Invite announcements configured')
        .setColor(0x57F287)
        .addFields(
          { name: 'Channel', value: `<#${channel.id}>`, inline: true },
          { name: 'Message', value: message },
        )
        .setFooter({ text: 'Placeholders: {member}, {inviter}, {count}, {code}' });
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'disable') {
      clearAnnounce(interaction.guild.id);
      return interaction.reply({ content: 'Invite announcements disabled.' });
    }

    if (sub === 'show') {
      const a = getAnnounce(interaction.guild.id);
      if (!a.channelId) return interaction.reply({ content: 'Invite announcements are not configured. Use `/inviteannounce set`.' });
      const embed = new EmbedBuilder()
        .setTitle('Invite announcement settings')
        .setColor(0x5865F2)
        .addFields(
          { name: 'Channel', value: `<#${a.channelId}>`, inline: true },
          { name: 'Message', value: a.message || EXAMPLE },
        )
        .setFooter({ text: 'Placeholders: {member}, {inviter}, {count}, {code}' });
      return interaction.reply({ embeds: [embed] });
    }
  },
  EXAMPLE,
};
