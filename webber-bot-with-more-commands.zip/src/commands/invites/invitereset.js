const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getInvites, setInvites } = require('../../utils/database');
const { applyInviteRewards } = require('../../utils/inviteRewards');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('invitereset')
    .setDescription('Reset a member\'s invite stats (and re-evaluate reward roles)')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addUserOption(opt => opt.setName('user').setDescription('Member to reset').setRequired(true)),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const rec = { total: 0, joins: 0, leaves: 0, bonus: 0 };
    setInvites(interaction.guild.id, user.id, rec);
    try {
      const member = await interaction.guild.members.fetch(user.id);
      await applyInviteRewards(member, 0);
    } catch {}
    await interaction.reply({ content: `Reset invite stats for **${user.tag}**.`, allowedMentions: { parse: [] } });
  },
};
