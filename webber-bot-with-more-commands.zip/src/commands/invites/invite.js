const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('invite')
    .setDescription('Create a server invite and DM it to a user by username')
    .setDefaultMemberPermissions(PermissionFlagsBits.CreateInstantInvite)
    .addStringOption(opt =>
      opt.setName('user')
        .setDescription('Username, @username, name#0000, or user ID')
        .setMaxLength(100)
        .setRequired(true))
    .addChannelOption(opt =>
      opt.setName('channel')
        .setDescription('Channel the invite should point to (defaults to current channel)')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
        .setRequired(false))
    .addStringOption(opt =>
      opt.setName('message')
        .setDescription('Custom message to include with the invite (optional)')
        .setMaxLength(1000)
        .setRequired(false))
    .addIntegerOption(opt =>
      opt.setName('max_uses')
        .setDescription('Max uses for the invite (0 = unlimited, default 1)')
        .setMinValue(0)
        .setMaxValue(100)
        .setRequired(false))
    .addIntegerOption(opt =>
      opt.setName('expires_hours')
        .setDescription('Invite expiry in hours (0 = never, default 0)')
        .setMinValue(0)
        .setMaxValue(168)
        .setRequired(false)),
  async execute(interaction, client) {
    const raw = interaction.options.getString('user', true).trim();
    const query = raw.replace(/^<@!?(\d+)>$/, '$1').replace(/^@/, '');
    const custom = interaction.options.getString('message');
    const maxUses = interaction.options.getInteger('max_uses') ?? 1;
    const expiresHours = interaction.options.getInteger('expires_hours') ?? 0;

    // Resolve by user ID (works even if the person is not in this server).
    let user = null;
    if (/^\d{17,20}$/.test(query)) {
      user = await client.users.fetch(query).catch(() => null);
    }

    // Otherwise resolve by username/tag from the bot's known users.
    if (!user) {
      const q = query.toLowerCase();
      user = client.users.cache.find(u =>
        u.username.toLowerCase() === q ||
        u.tag.toLowerCase() === q ||
        u.username.toLowerCase().startsWith(q)
      ) || null;

      // Fall back to searching members of every server the bot is in.
      if (!user) {
        for (const guild of client.guilds.cache.values()) {
          try {
            const found = await guild.members.fetch({ query, limit: 10 }).catch(() => null);
            if (found && found.size) {
              user = found.find(m =>
                m.user.username.toLowerCase() === q ||
                m.user.tag.toLowerCase() === q
              )?.user || found.first()?.user;
              if (user) break;
            }
          } catch {}
        }
      }
    }

    if (!user) {
      return interaction.reply({
        content: `I couldn't find **${raw}**. Use their exact username, or their **user ID** (right-click → Copy User ID with Developer Mode on). A user ID works even if they aren't in the server yet.`,
        ephemeral: true,
      });
    }

    const channel = interaction.options.getChannel('channel') || interaction.channel;
    if (!channel || !channel.isTextBased() || !channel.createInvite) {
      return interaction.reply({ content: 'Please specify a text channel for the invite.', ephemeral: true });
    }
    if (!channel.guild || channel.guild.id !== interaction.guild.id) {
      return interaction.reply({ content: 'The channel must be in this server.', ephemeral: true });
    }

    let invite;
    try {
      invite = await channel.createInvite({
        maxAge: expiresHours * 3600,
        maxUses,
        unique: true,
        reason: `Invite requested by ${interaction.user.tag} for ${user.tag}`,
      });
    } catch (err) {
      console.error('Failed to create invite:', err);
      return interaction.reply({ content: 'I could not create an invite in that channel. Make sure I have **Create Invite** permission there.', ephemeral: true });
    }

    const body = custom
      ? `${custom}\n\n**Server:** ${interaction.guild.name}\n**Invite:** ${invite.url}`
      : `You've been invited to **${interaction.guild.name}**!\n\n${invite.url}`;

    try {
      await user.send(body);
      await interaction.reply({
        content: `Sent the invite to **${user.tag}** in DMs.${custom ? ' Included your custom message.' : ''}\nInvite: ${invite.url}\nExpires: ${expiresHours === 0 ? 'never' : `in ${expiresHours}h`} | Uses: ${maxUses === 0 ? 'unlimited' : maxUses}`,
        allowedMentions: { parse: [] },
        ephemeral: true,
      });
    } catch (err) {
      await interaction.reply({
        content: `I created the invite but couldn't DM **${user.tag}** (their DMs may be closed or I can't reach them). You can send it yourself:\n${invite.url}`,
        allowedMentions: { parse: [] },
        ephemeral: true,
      });
    }
  },
};
