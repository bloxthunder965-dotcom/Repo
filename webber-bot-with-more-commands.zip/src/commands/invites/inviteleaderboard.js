const { SlashCommandBuilder } = require('discord.js');
const { read } = require('../../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('inviteleaderboard')
    .setDescription('Show the top inviters in this server'),
  async execute(interaction) {
    const db = read();
    const guild = db.guilds[interaction.guild.id];
    const invites = (guild && guild.invites) || {};
    const sorted = Object.entries(invites)
      .map(([userId, rec]) => ({ userId, total: rec.total || 0 }))
      .filter(x => x.total > 0)
      .sort((a, b) => b.total - a.total)
      .slice(0, 10);
    if (!sorted.length) return interaction.reply({ content: 'No invite data yet.' });
    const lines = sorted.map((x, i) => `**${i + 1}.** <@${x.userId}> — **${x.total}** invite(s)`);
    await interaction.reply({ content: `**Invite Leaderboard**\n${lines.join('\n')}`, allowedMentions: { parse: [] } });
  },
};
