const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { addBonus, getInvites } = require('../../utils/database');
const { applyInviteRewards } = require('../../utils/inviteRewards');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('invitebonus')
    .setDescription('Add or remove bonus invites for a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addUserOption(opt => opt.setName('user').setDescription('Member to adjust').setRequired(true))
    .addIntegerOption(opt => opt.setName('amount').setDescription('Amount to add (use negative to remove)').setRequired(true)),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const amount = interaction.options.getInteger('amount', true);
    const rec = addBonus(interaction.guild.id, user.id, amount);
    try {
      const member = await interaction.guild.members.fetch(user.id);
      await applyInviteRewards(member, rec.total);
    } catch {}
    await interaction.reply({ content: `Adjusted bonus for **${user.tag}** by **${amount}**. New total: **${rec.total}**.`, allowedMentions: { parse: [] } });
  },
};
