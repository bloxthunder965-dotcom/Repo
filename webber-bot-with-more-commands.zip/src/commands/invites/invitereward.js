const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { setReward, removeReward, getRewards } = require('../../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('invitereward')
    .setDescription('Configure invite role rewards')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub =>
      sub.setName('add')
        .setDescription('Assign a role when a member reaches an invite count')
        .addIntegerOption(opt => opt.setName('invites').setDescription('Number of invites required').setMinValue(1).setRequired(true))
        .addRoleOption(opt => opt.setName('role').setDescription('Role to award').setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('remove')
        .setDescription('Remove the reward for an invite count')
        .addIntegerOption(opt => opt.setName('invites').setDescription('Invite count threshold to remove').setMinValue(1).setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('List configured invite rewards')),
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    if (sub === 'add') {
      const invites = interaction.options.getInteger('invites', true);
      const role = interaction.options.getRole('role', true);
      if (role.managed) return interaction.reply({ content: 'I cannot assign a managed/integration role.', ephemeral: true });
      setReward(interaction.guild.id, invites, role.id);
      return interaction.reply({ content: `Set reward: **${invites}** invite(s) → ${role}.` });
    }
    if (sub === 'remove') {
      const invites = interaction.options.getInteger('invites', true);
      removeReward(interaction.guild.id, invites);
      return interaction.reply({ content: `Removed reward for **${invites}** invite(s), if it existed.` });
    }
    if (sub === 'list') {
      const rewards = getRewards(interaction.guild.id);
      const entries = Object.entries(rewards).sort((a, b) => Number(a[0]) - Number(b[0]));
      if (!entries.length) return interaction.reply({ content: 'No invite rewards configured yet.' });
      const lines = entries.map(([count, roleId]) => `• **${count}** invite(s) → <@&${roleId}> (\`${roleId}\`)`);
      return interaction.reply({ content: `**Invite Rewards**\n${lines.join('\n')}` });
    }
  },
};
