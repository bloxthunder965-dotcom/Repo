const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('role')
    .setDescription('Add or remove a role from a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand(sub =>
      sub.setName('add')
        .setDescription('Add a role to a member')
        .addUserOption(opt => opt.setName('user').setDescription('Member').setRequired(true))
        .addRoleOption(opt => opt.setName('role').setDescription('Role to add').setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('remove')
        .setDescription('Remove a role from a member')
        .addUserOption(opt => opt.setName('user').setDescription('Member').setRequired(true))
        .addRoleOption(opt => opt.setName('role').setDescription('Role to remove').setRequired(true))),
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const user = interaction.options.getUser('user', true);
    const role = interaction.options.getRole('role', true);
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) return interaction.reply({ content: 'That user is not in this server.', ephemeral: true });
    if (role.managed) return interaction.reply({ content: 'I cannot manage an integration/managed role.', ephemeral: true });

    const me = interaction.guild.members.me;
    if (!me || role.position >= me.roles.highest.position) {
      return interaction.reply({ content: 'I cannot manage that role due to role hierarchy (my highest role must be above it).', ephemeral: true });
    }

    if (sub === 'add') {
      if (member.roles.cache.has(role.id)) return interaction.reply({ content: `**${user.tag}** already has ${role}.`, allowedMentions: { parse: [] } });
      await member.roles.add(role);
      return interaction.reply({ content: `Added ${role} to **${user.tag}**.`, allowedMentions: { parse: [] } });
    } else {
      if (!member.roles.cache.has(role.id)) return interaction.reply({ content: `**${user.tag}** does not have ${role}.`, allowedMentions: { parse: [] } });
      await member.roles.remove(role);
      return interaction.reply({ content: `Removed ${role} from **${user.tag}**.`, allowedMentions: { parse: [] } });
    }
  },
};
