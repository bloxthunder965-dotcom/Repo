const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('Unlock the current channel (allow @everyone to send messages)')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  async execute(interaction) {
    const channel = interaction.channel;
    if (!channel || !channel.permissionOverwrites) {
      return interaction.reply({ content: 'Cannot manage permissions in this channel.', ephemeral: true });
    }
    await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, { SendMessages: null });
    await interaction.reply({ content: '🔓 Channel unlocked.' });
  },
};
