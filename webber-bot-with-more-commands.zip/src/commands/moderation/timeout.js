const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout (mute) a member for a duration')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(opt => opt.setName('user').setDescription('Member to timeout').setRequired(true))
    .addIntegerOption(opt => opt.setName('minutes').setDescription('Duration in minutes (1-40320)').setMinValue(1).setMaxValue(40320).setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for the timeout')),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const minutes = interaction.options.getInteger('minutes', true);
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) return interaction.reply({ content: 'That user is not in this server.', ephemeral: true });
    if (!member.moderatable) return interaction.reply({ content: 'I cannot timeout that member (role hierarchy or missing permissions).', ephemeral: true });
    await member.timeout(minutes * 60 * 1000, reason);
    await interaction.reply({ content: `Timed out **${user.tag}** for **${minutes}** minute(s). Reason: ${reason}`, allowedMentions: { parse: [] } });
  },
};
