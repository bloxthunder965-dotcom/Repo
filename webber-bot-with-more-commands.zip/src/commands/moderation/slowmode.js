const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('slowmode')
    .setDescription('Set slowmode for the current channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addIntegerOption(opt => opt.setName('seconds').setDescription('Slowmode delay in seconds (0 to disable, max 21600)').setMinValue(0).setMaxValue(21600).setRequired(true)),
  async execute(interaction) {
    const seconds = interaction.options.getInteger('seconds', true);
    const channel = interaction.channel;
    if (!channel || typeof channel.setRateLimitPerUser !== 'function') {
      return interaction.reply({ content: 'Slowmode is not supported in this channel.', ephemeral: true });
    }
    await channel.setRateLimitPerUser(seconds);
    await interaction.reply({ content: seconds === 0 ? 'Slowmode disabled.' : `Slowmode set to **${seconds}** second(s).` });
  },
};
