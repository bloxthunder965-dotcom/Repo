const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unban a user by their user ID')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addStringOption(opt => opt.setName('user_id').setDescription('ID of the user to unban').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for the unban')),
  async execute(interaction) {
    const userId = interaction.options.getString('user_id', true);
    const reason = interaction.options.getString('reason') || 'No reason provided';
    try {
      const user = await interaction.guild.members.unban(userId, reason);
      await interaction.reply({ content: `Unbanned **${user.tag}**. Reason: ${reason}`, allowedMentions: { parse: [] } });
    } catch {
      await interaction.reply({ content: 'Could not unban that user. Check the ID and ban list.', ephemeral: true });
    }
  },
};
