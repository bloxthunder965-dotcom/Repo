const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('softban')
    .setDescription('Ban a member to delete their messages, then unban them')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(opt => opt.setName('user').setDescription('Member to softban').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for the softban').setMaxLength(1000)),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const reason = interaction.options.getString('reason') || 'No reason provided';

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      return interaction.reply({ content: 'That user is not in this server.', ephemeral: true });
    }
    if (!member.bannable) {
      return interaction.reply({ content: 'I cannot ban that member (role hierarchy or missing permissions).', ephemeral: true });
    }

    try {
      await member.ban({ deleteMessageSeconds: 7 * 24 * 60 * 60, reason });
    } catch (err) {
      console.error('softban: ban failed', err);
      return interaction.reply({ content: 'I could not ban that member.', ephemeral: true });
    }

    try {
      await interaction.guild.members.unban(user.id, `Softban by ${interaction.user.tag}`);
    } catch (err) {
      console.error('softban: unban failed — member is still banned', err);
      return interaction.reply({
        content: `Messages were deleted, but I could not unban **${user.tag}**. Unban them manually with \`/unban\`.`,
        ephemeral: true,
        allowedMentions: { parse: [] },
      });
    }

    await interaction.reply({
      content: `Softbanned **${user.tag}** (messages from the last 7 days deleted). Reason: ${reason}`,
      allowedMentions: { parse: [] },
    });
  },
};
