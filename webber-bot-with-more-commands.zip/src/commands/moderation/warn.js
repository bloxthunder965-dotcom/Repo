const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');
const { addWarn, getWarns } = require('../../utils/warns');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(opt => opt.setName('user').setDescription('Member to warn').setRequired(true))
    .addStringOption(opt => opt.setName('reason').setDescription('Reason for the warning').setMaxLength(1000).setRequired(true))
    .addBooleanOption(opt => opt.setName('dm').setDescription('DM the warning to the user (default: yes)')),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const reason = interaction.options.getString('reason', true);
    const dm = interaction.options.getBoolean('dm') ?? true;

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      return interaction.reply({ content: 'That user is not in this server.', ephemeral: true });
    }

    const entry = addWarn(interaction.guild.id, user.id, {
      reason,
      moderatorId: interaction.user.id,
    });
    const count = getWarns(interaction.guild.id, user.id).length;

    if (dm) {
      await user.send(
        `You were warned in **${interaction.guild.name}**.\nReason: ${reason}\nTotal warnings: **${count}**`,
      ).catch(() => {});
    }

    const embed = new EmbedBuilder()
      .setTitle('Member warned')
      .setColor(0xFEE75C)
      .addFields(
        { name: 'Member', value: `${user.tag} (<@${user.id}>)`, inline: true },
        { name: 'Moderator', value: `${interaction.user.tag}`, inline: true },
        { name: 'Warning #', value: String(count), inline: true },
        { name: 'Reason', value: reason },
      )
      .setFooter({ text: `Warning ID: ${entry.id}` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed], allowedMentions: { parse: [] } });
  },
};
