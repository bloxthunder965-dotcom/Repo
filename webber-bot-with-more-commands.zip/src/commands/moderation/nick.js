const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('nick')
    .setDescription('Change a member\'s nickname')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageNicknames)
    .addUserOption(opt => opt.setName('user').setDescription('Member to change nickname for').setRequired(true))
    .addStringOption(opt => opt.setName('nickname').setDescription('New nickname (leave empty to reset)').setMaxLength(32)),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const nickname = interaction.options.getString('nickname');
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) return interaction.reply({ content: 'That user is not in this server.', ephemeral: true });
    if (!member.manageable) return interaction.reply({ content: 'I cannot change that member\'s nickname (role hierarchy).', ephemeral: true });
    await member.setNickname(nickname || null);
    await interaction.reply({ content: nickname ? `Set nickname for **${user.tag}** to **${nickname}**.` : `Reset nickname for **${user.tag}**.`, allowedMentions: { parse: [] } });
  },
};
