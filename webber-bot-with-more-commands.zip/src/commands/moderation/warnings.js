const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');
const { getWarns } = require('../../utils/warns');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('Show warnings for a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(opt => opt.setName('user').setDescription('Member to check').setRequired(true)),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const warnings = getWarns(interaction.guild.id, user.id);

    if (!warnings.length) {
      return interaction.reply({ content: `**${user.tag}** has no warnings.`, allowedMentions: { parse: [] } });
    }

    const lines = warnings.slice(0, 20).map((w, i) => {
      const mod = w.moderatorId ? `<@${w.moderatorId}>` : 'Unknown';
      return `**${i + 1}.** ${w.reason}\n— by ${mod} <t:${Math.floor(w.at / 1000)}:R>`;
    });
    if (warnings.length > 20) lines.push(`…and ${warnings.length - 20} more.`);

    const embed = new EmbedBuilder()
      .setTitle(`Warnings for ${user.tag}`)
      .setColor(0xED4245)
      .setThumbnail(user.displayAvatarURL({ size: 256 }))
      .setDescription(lines.join('\n\n'))
      .setFooter({ text: `Total: ${warnings.length} | Remove one with /clearwarnings` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed], allowedMentions: { parse: [] } });
  },
};
