const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Delete a number of recent messages in this channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption(opt => opt.setName('amount').setDescription('Number of messages to delete (1-100)').setMinValue(1).setMaxValue(100).setRequired(true)),
  async execute(interaction) {
    const amount = interaction.options.getInteger('amount', true);
    const channel = interaction.channel;
    if (!channel || !channel.isTextBased() || channel.isDMBased()) {
      return interaction.reply({ content: 'This command can only be used in a server text channel.', ephemeral: true });
    }
    const deleted = await channel.bulkDelete(amount, true).catch(() => null);
    if (!deleted) return interaction.reply({ content: 'Failed to delete messages (they may be older than 14 days).', ephemeral: true });
    await interaction.reply({ content: `Deleted **${deleted.size}** message(s).`, ephemeral: true });
  },
};
