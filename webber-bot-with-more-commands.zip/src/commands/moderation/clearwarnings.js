const {
  SlashCommandBuilder,
  PermissionFlagsBits,
} = require('discord.js');
const { getWarns, removeWarn, clearWarns } = require('../../utils/warns');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clearwarnings')
    .setDescription('Remove warnings from a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(opt => opt.setName('user').setDescription('Member to clear warnings for').setRequired(true))
    .addIntegerOption(opt => opt.setName('index').setDescription('Warning number to remove (see /warnings)').setMinValue(1).setMaxValue(100))
    .addBooleanOption(opt => opt.setName('all').setDescription('Remove all warnings for this member')),
  async execute(interaction) {
    const user = interaction.options.getUser('user', true);
    const index = interaction.options.getInteger('index');
    const all = interaction.options.getBoolean('all');
    const warnings = getWarns(interaction.guild.id, user.id);

    if (!warnings.length) {
      return interaction.reply({ content: `**${user.tag}** has no warnings.`, ephemeral: true, allowedMentions: { parse: [] } });
    }

    if (all) {
      const count = clearWarns(interaction.guild.id, user.id);
      return interaction.reply({ content: `Cleared **${count}** warning(s) from **${user.tag}**.`, allowedMentions: { parse: [] } });
    }

    if (!index) {
      return interaction.reply({
        content: `**${user.tag}** has **${warnings.length}** warning(s). Use \`index:1\` to remove one, or \`all:true\` to clear them all.`,
        ephemeral: true,
        allowedMentions: { parse: [] },
      });
    }

    if (index > warnings.length) {
      return interaction.reply({ content: `There is no warning #${index} for **${user.tag}**.`, ephemeral: true, allowedMentions: { parse: [] } });
    }

    const removed = removeWarn(interaction.guild.id, user.id, warnings[index - 1].id);
    if (!removed) {
      return interaction.reply({ content: 'That warning could not be removed.', ephemeral: true });
    }

    return interaction.reply({
      content: `Removed warning **#${index}** from **${user.tag}**. Reason: ${removed.reason}`,
      allowedMentions: { parse: [] },
    });
  },
};
