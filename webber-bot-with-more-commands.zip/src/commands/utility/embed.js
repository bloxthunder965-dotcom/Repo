const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ChannelType,
} = require('discord.js');

const COLORS = {
  blue: 0x5865F2,
  green: 0x57F287,
  red: 0xED4245,
  yellow: 0xFEE75C,
  purple: 0x9B59B6,
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('embed')
    .setDescription('Send an embedded message to a channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addStringOption(opt => opt.setName('title').setDescription('Embed title').setMaxLength(256).setRequired(true))
    .addStringOption(opt => opt.setName('description').setDescription('Embed description').setMaxLength(4000).setRequired(true))
    .addStringOption(opt => opt.setName('color')
      .setDescription('Embed color (default: blue)')
      .addChoices(
        { name: 'Blue', value: 'blue' },
        { name: 'Green', value: 'green' },
        { name: 'Red', value: 'red' },
        { name: 'Yellow', value: 'yellow' },
        { name: 'Purple', value: 'purple' },
      ))
    .addStringOption(opt => opt.setName('footer').setDescription('Embed footer text').setMaxLength(2048))
    .addChannelOption(opt => opt.setName('channel')
      .setDescription('Channel to send to (defaults to current)')
      .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)),
  async execute(interaction) {
    const title = interaction.options.getString('title', true);
    const description = interaction.options.getString('description', true);
    const color = COLORS[interaction.options.getString('color') || 'blue'] || COLORS.blue;
    const footer = interaction.options.getString('footer');
    const channel = interaction.options.getChannel('channel') || interaction.channel;

    if (!channel || !channel.isTextBased() || !channel.guild || channel.guild.id !== interaction.guild.id) {
      return interaction.reply({ content: 'Please choose a text channel in this server.', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setTitle(title)
      .setDescription(description)
      .setColor(color)
      .setTimestamp();
    if (footer) embed.setFooter({ text: footer });

    try {
      await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
    } catch (err) {
      console.error('embed: send failed', err);
      return interaction.reply({ content: 'I could not send that embed. Check my permissions in the channel.', ephemeral: true });
    }

    await interaction.reply({ content: `Embed sent to <#${channel.id}>.`, ephemeral: true, allowedMentions: { parse: [] } });
  },
};
