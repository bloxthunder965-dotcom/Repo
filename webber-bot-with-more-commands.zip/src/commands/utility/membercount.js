const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('membercount')
    .setDescription('Show the server member count breakdown'),
  async execute(interaction) {
    const guild = interaction.guild;
    const members = await guild.members.fetch().catch(() => null);
    const bots = members ? members.filter(m => m.user.bot).size : null;
    const humans = members ? members.size - bots : null;

    const embed = new EmbedBuilder()
      .setTitle(`${guild.name} — Members`)
      .setThumbnail(guild.iconURL({ size: 256 }))
      .setColor(0x57F287)
      .addFields(
        { name: 'Total', value: String(guild.memberCount), inline: true },
        { name: 'Humans', value: humans === null ? 'Unknown' : String(humans), inline: true },
        { name: 'Bots', value: bots === null ? 'Unknown' : String(bots), inline: true },
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
