const { SlashCommandBuilder, EmbedBuilder, version } = require('discord.js');

function uptime(seconds) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${d}d ${h}h ${m}m ${s}s`;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('botinfo')
    .setDescription('Show information about the bot'),
  async execute(interaction, client) {
    const totalUsers = client.guilds.cache.reduce((sum, g) => sum + g.memberCount, 0);
    const memory = Math.round(process.memoryUsage().heapUsed / 1024 / 1024);
    const embed = new EmbedBuilder()
      .setTitle(`${client.user.tag} — Bot Info`)
      .setThumbnail(client.user.displayAvatarURL({ size: 256 }))
      .setColor(0x5865F2)
      .addFields(
        { name: 'Uptime', value: uptime(process.uptime()), inline: true },
        { name: 'Ping', value: `${Math.round(client.ws.ping)}ms`, inline: true },
        { name: 'Servers', value: String(client.guilds.cache.size), inline: true },
        { name: 'Users (approx.)', value: String(totalUsers), inline: true },
        { name: 'Library', value: `discord.js v${version}`, inline: true },
        { name: 'Node', value: process.version, inline: true },
        { name: 'Memory', value: `${memory} MB`, inline: true },
        { name: 'Commands', value: String(client.commands.size), inline: true },
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
