const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Show available bot commands'),
  async execute(interaction, client) {
    const categories = {
      Invites: ['invites', 'invite', 'invitereward', 'invitebonus', 'inviteleaderboard', 'invitereset', 'inviteannounce'],
      Moderation: ['kick', 'ban', 'unban', 'softban', 'timeout', 'untimeout', 'purge', 'slowmode', 'lock', 'unlock', 'nick', 'warn', 'warnings', 'clearwarnings'],
      Roles: ['role'],
      Utility: ['help', 'ping', 'serverinfo', 'userinfo', 'avatar', 'botinfo', 'roleinfo', 'channelinfo', 'membercount', 'snowflake', 'embed', 'poll', 'announce'],
      Fun: ['roll', 'choose', 'coinflip', '8ball', 'rps', 'reverse'],
    };

    const desc = (name) => {
      const cmd = client.commands.get(name);
      return cmd ? cmd.data.description : 'No description';
    };

    const embed = new EmbedBuilder()
      .setTitle('clipsieXD — Help')
      .setColor(0x5865F2)
      .setDescription('Here are the available slash commands:')
      .setTimestamp();

    for (const [cat, names] of Object.entries(categories)) {
      const lines = names
        .filter(n => client.commands.has(n))
        .map(n => `• \`/${n}\` — ${desc(n)}`);
      if (lines.length) embed.addFields({ name: cat, value: lines.join('\n') });
    }

    const known = new Set(Object.values(categories).flat());
    const extras = [...client.commands.keys()].filter(n => !known.has(n)).map(n => `• \`/${n}\` — ${desc(n)}`);
    if (extras.length) embed.addFields({ name: 'Other', value: extras.join('\n') });

    await interaction.reply({ embeds: [embed] });
  },
};
