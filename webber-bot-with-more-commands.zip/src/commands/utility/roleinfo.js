const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('roleinfo')
    .setDescription('Show information about a role')
    .addRoleOption(opt => opt.setName('role').setDescription('Role to inspect').setRequired(true)),
  async execute(interaction) {
    const role = interaction.options.getRole('role', true);
    const perms = role.permissions.toArray();
    const permText = (perms.length ? perms.join(', ') : 'None').slice(0, 900);

    const embed = new EmbedBuilder()
      .setTitle(`Role: ${role.name}`)
      .setColor(role.color || 0x5865F2)
      .addFields(
        { name: 'Role ID', value: role.id, inline: true },
        { name: 'Members', value: String(role.members.size), inline: true },
        { name: 'Position', value: String(role.position), inline: true },
        { name: 'Color', value: role.color ? `#${role.color.toString(16).padStart(6, '0')}` : 'Default', inline: true },
        { name: 'Created', value: `<t:${Math.floor(role.createdTimestamp / 1000)}:R>`, inline: true },
        { name: 'Managed', value: role.managed ? 'Yes' : 'No', inline: true },
        { name: 'Mentionable', value: role.mentionable ? 'Yes' : 'No', inline: true },
        { name: `Permissions (${perms.length})`, value: permText },
      )
      .setTimestamp();

    if (role.permissions.has(PermissionFlagsBits.Administrator)) {
      embed.setFooter({ text: 'This role has Administrator.' });
    }

    await interaction.reply({ embeds: [embed], allowedMentions: { parse: [] } });
  },
};
