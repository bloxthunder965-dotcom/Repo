const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const EPOCH = 1420070400000n;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('snowflake')
    .setDescription('Show when a Discord ID was created')
    .addStringOption(opt => opt.setName('id').setDescription('Discord ID (user, channel, role, message, server...)').setMinLength(17).setMaxLength(20).setRequired(true)),
  async execute(interaction) {
    const id = interaction.options.getString('id', true).trim();
    if (!/^\d{17,20}$/.test(id)) {
      return interaction.reply({ content: 'That does not look like a Discord ID (17–20 digits).', ephemeral: true });
    }

    const value = BigInt(id);
    const created = Number((value >> 22n) + EPOCH);
    const worker = Number((value >> 17n) & 31n);
    const processId = Number((value >> 12n) & 31n);
    const increment = Number(value & 4095n);

    const embed = new EmbedBuilder()
      .setTitle('Snowflake lookup')
      .setColor(0x5865F2)
      .addFields(
        { name: 'ID', value: id },
        { name: 'Created', value: `<t:${Math.floor(created / 1000)}:F>\n<t:${Math.floor(created / 1000)}:R>` },
        { name: 'Worker / Process / Increment', value: `${worker} / ${processId} / ${increment}`, inline: true },
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
