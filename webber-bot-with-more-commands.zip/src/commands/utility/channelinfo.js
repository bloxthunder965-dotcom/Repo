const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('channelinfo')
    .setDescription('Show information about a channel')
    .addChannelOption(opt => opt.setName('channel').setDescription('Channel to inspect (defaults to current)')),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    if (!channel) {
      return interaction.reply({ content: 'Could not find that channel.', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setTitle(`Channel: ${channel.name}`)
      .setColor(0x5865F2)
      .addFields(
        { name: 'Channel ID', value: channel.id, inline: true },
        { name: 'Type', value: ChannelType[channel.type] || String(channel.type), inline: true },
        { name: 'Created', value: `<t:${Math.floor(channel.createdTimestamp / 1000)}:R>`, inline: true },
        { name: 'Category', value: channel.parent?.name || 'None', inline: true },
        { name: 'NSFW', value: channel.nsfw ? 'Yes' : 'No', inline: true },
      );

    if (typeof channel.rateLimitPerUser === 'number') {
      embed.addFields({ name: 'Slowmode', value: `${channel.rateLimitPerUser}s`, inline: true });
    }
    if (channel.topic) {
      embed.addFields({ name: 'Topic', value: channel.topic.slice(0, 1000) });
    }

    await interaction.reply({ embeds: [embed], allowedMentions: { parse: [] } });
  },
};
