const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ChannelType,
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('announce')
    .setDescription('Post an announcement embed in a channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addStringOption(opt => opt.setName('message').setDescription('Announcement text').setMaxLength(4000).setRequired(true))
    .addStringOption(opt => opt.setName('title').setDescription('Embed title (optional)').setMaxLength(256))
    .addChannelOption(opt => opt.setName('channel')
      .setDescription('Channel to announce in (defaults to current)')
      .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)),
  async execute(interaction) {
    const message = interaction.options.getString('message', true);
    const title = interaction.options.getString('title');
    const channel = interaction.options.getChannel('channel') || interaction.channel;

    if (!channel || !channel.isTextBased() || !channel.guild || channel.guild.id !== interaction.guild.id) {
      return interaction.reply({ content: 'Please choose a text channel in this server.', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0xFAA61C)
      .setDescription(message)
      .setFooter({ text: `Announcement by ${interaction.user.tag}` })
      .setTimestamp();
    if (title) embed.setTitle(title);

    try {
      await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
    } catch (err) {
      console.error('announce: send failed', err);
      return interaction.reply({ content: 'I could not post the announcement. Check my permissions in the channel.', ephemeral: true });
    }

    await interaction.reply({ content: `Announcement sent to <#${channel.id}>.`, ephemeral: true, allowedMentions: { parse: [] } });
  },
};
