const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ChannelType,
} = require('discord.js');

const EMOJIS = ['1️⃣', '2️⃣', '3️⃣', '4️⃣'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Create a reaction poll (up to 4 options)')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addStringOption(opt => opt.setName('question').setDescription('Poll question').setMaxLength(256).setRequired(true))
    .addStringOption(opt => opt.setName('option1').setDescription('First option').setMaxLength(200).setRequired(true))
    .addStringOption(opt => opt.setName('option2').setDescription('Second option').setMaxLength(200).setRequired(true))
    .addStringOption(opt => opt.setName('option3').setDescription('Third option (optional)').setMaxLength(200))
    .addStringOption(opt => opt.setName('option4').setDescription('Fourth option (optional)').setMaxLength(200))
    .addChannelOption(opt => opt.setName('channel')
      .setDescription('Channel to post the poll in (defaults to current)')
      .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)),
  async execute(interaction) {
    const question = interaction.options.getString('question', true);
    const options = [1, 2, 3, 4]
      .map(n => interaction.options.getString(`option${n}`))
      .filter(Boolean);
    const channel = interaction.options.getChannel('channel') || interaction.channel;

    if (!channel || !channel.isTextBased() || !channel.guild || channel.guild.id !== interaction.guild.id) {
      return interaction.reply({ content: 'Please choose a text channel in this server.', ephemeral: true });
    }

    const lines = options.map((opt, i) => `${EMOJIS[i]} ${opt}`).join('\n');
    const embed = new EmbedBuilder()
      .setTitle('📊 Poll')
      .setDescription(`**${question}**\n\n${lines}`)
      .setColor(0x9B59B6)
      .setFooter({ text: `Started by ${interaction.user.tag} — react to vote` })
      .setTimestamp();

    let message;
    try {
      message = await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
    } catch (err) {
      console.error('poll: send failed', err);
      return interaction.reply({ content: 'I could not post the poll. Check my permissions in the channel.', ephemeral: true });
    }

    for (let i = 0; i < options.length; i++) {
      try {
        await message.react(EMOJIS[i]);
      } catch {
        break;
      }
    }

    await interaction.reply({
      content: `Poll created: ${message.url}`,
      ephemeral: true,
      allowedMentions: { parse: [] },
    });
  },
};
