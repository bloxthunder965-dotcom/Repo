const { Events } = require('discord.js');

module.exports = {
  name: Events.InviteCreate,
  async execute(invite, client) {
    const cache = client.inviteCache.get(invite.guild.id) || new Map();
    cache.set(invite.code, invite.uses || 0);
    client.inviteCache.set(invite.guild.id, cache);
  },
};
