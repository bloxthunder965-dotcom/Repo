const { Events } = require('discord.js');
const { addInvite, recordJoin, getAnnounce } = require('../utils/database');
const { applyInviteRewards } = require('../utils/inviteRewards');
const { EXAMPLE } = require('../commands/invites/inviteannounce');

module.exports = {
  name: Events.GuildMemberAdd,
  async execute(member, client) {
    if (member.user.bot) return;
    const guild = member.guild;
    const cached = client.inviteCache.get(guild.id) || new Map();
    let usedInvite = null;
    try {
      const newInvites = await guild.invites.fetch();
      for (const [code, invite] of newInvites) {
        const prev = cached.get(code) || 0;
        const now = invite.uses || 0;
        if (now > prev) {
          usedInvite = invite;
          break;
        }
      }
      client.inviteCache.set(guild.id, new Map(newInvites.map(i => [i.code, i.uses || 0])));
    } catch (err) {
      console.warn(`Invite check failed for ${guild.id}:`, err.message);
      return;
    }

    if (!usedInvite || !usedInvite.inviter) return;
    const inviterId = usedInvite.inviter.id;
    const inviter = usedInvite.inviter;
    recordJoin(guild.id, member.id, inviterId);
    const rec = addInvite(guild.id, inviterId, 1);

    try {
      const inviterMember = await guild.members.fetch(inviterId);
      await applyInviteRewards(inviterMember, rec.total);
    } catch {}

    // Invite announcement
    const announce = getAnnounce(guild.id);
    if (announce.channelId) {
      const channel = guild.channels.cache.get(announce.channelId);
      if (channel && channel.isTextBased()) {
        const template = announce.message || EXAMPLE;
        const text = template
          .replaceAll('{member}', `<@${member.id}>`)
          .replaceAll('{inviter}', `<@${inviterId}>`)
          .replaceAll('{count}', String(rec.total))
          .replaceAll('{code}', usedInvite.code);
        await channel.send({
          content: text,
          allowedMentions: { users: [member.id, inviterId] },
        }).catch(() => {});
      }
    }
  },
};
