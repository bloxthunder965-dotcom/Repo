const { Events } = require('discord.js');

module.exports = {
  name: Events.ClientReady,
  once: true,
  async execute(client) {
    console.log(`Logged in as ${client.user.tag}`);
    for (const [guildId, guild] of client.guilds.cache) {
      try {
        const invites = await guild.invites.fetch();
        client.inviteCache.set(guildId, new Map(invites.map(i => [i.code, i.uses || 0])));
      } catch (err) {
        console.warn(`Could not cache invites for guild ${guildId}:`, err.message);
        client.inviteCache.set(guildId, new Map());
      }
    }
  },
};
