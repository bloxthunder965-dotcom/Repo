const { getRewards } = require('./database');

async function applyInviteRewards(member, totalInvites) {
  const rewards = getRewards(member.guild.id);
  const entries = Object.entries(rewards)
    .map(([count, roleId]) => ({ count: Number(count), roleId }))
    .filter(e => !Number.isNaN(e.count) && e.roleId)
    .sort((a, b) => a.count - b.count);

  const added = [];
  const removed = [];
  for (const { count, roleId } of entries) {
    const role = member.guild.roles.cache.get(roleId);
    if (!role) continue;
    const has = member.roles.cache.has(roleId);
    if (totalInvites >= count && !has) {
      try { await member.roles.add(role, `Invite reward: ${count} invites`); added.push(roleId); } catch {}
    } else if (totalInvites < count && has) {
      try { await member.roles.remove(role, `Invite count below ${count}`); removed.push(roleId); } catch {}
    }
  }
  return { added, removed };
}

module.exports = { applyInviteRewards };
