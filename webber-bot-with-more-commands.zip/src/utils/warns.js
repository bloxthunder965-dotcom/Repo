const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', '..', 'data');
const FILE = path.join(DATA_DIR, 'warns.json');

function ensure() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(FILE)) {
    fs.writeFileSync(FILE, JSON.stringify({ guilds: {} }, null, 2));
  }
}

function read() {
  ensure();
  try {
    const data = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    if (!data.guilds) data.guilds = {};
    return data;
  } catch {
    return { guilds: {} };
  }
}

function write(data) {
  ensure();
  fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
}

function guild(data, guildId) {
  if (!data.guilds[guildId]) data.guilds[guildId] = {};
  return data.guilds[guildId];
}

function addWarn(guildId, userId, warning) {
  const data = read();
  const g = guild(data, guildId);
  if (!g[userId]) g[userId] = [];
  const entry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    reason: warning.reason,
    moderatorId: warning.moderatorId,
    at: Date.now(),
  };
  g[userId].push(entry);
  write(data);
  return entry;
}

function getWarns(guildId, userId) {
  const data = read();
  return guild(data, guildId)[userId] || [];
}

function removeWarn(guildId, userId, warnId) {
  const data = read();
  const g = guild(data, guildId);
  const list = g[userId] || [];
  const index = list.findIndex(w => w.id === warnId);
  if (index === -1) return null;
  const [removed] = list.splice(index, 1);
  if (!list.length) delete g[userId];
  write(data);
  return removed;
}

function clearWarns(guildId, userId) {
  const data = read();
  const g = guild(data, guildId);
  const count = (g[userId] || []).length;
  delete g[userId];
  write(data);
  return count;
}

module.exports = { addWarn, getWarns, removeWarn, clearWarns };
