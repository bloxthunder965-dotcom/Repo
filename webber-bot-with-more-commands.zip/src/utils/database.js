const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', '..', 'data');
const DB_PATH = path.join(DATA_DIR, 'db.json');

function ensure() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify({ guilds: {} }, null, 2));
  }
}

function read() {
  ensure();
  try {
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  } catch {
    return { guilds: {} };
  }
}

function write(data) {
  ensure();
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function getGuild(data, guildId) {
  if (!data.guilds[guildId]) {
    data.guilds[guildId] = { invites: {}, rewards: {}, logs: {} };
  }
  const g = data.guilds[guildId];
  g.invites ||= {};
  g.rewards ||= {};
  g.logs ||= {};
  g.announce ||= { channelId: null, message: null };
  return g;
}

function getInvites(guildId, userId) {
  const data = read();
  const g = getGuild(data, guildId);
  return g.invites[userId] || { total: 0, joins: 0, leaves: 0, bonus: 0 };
}

function setInvites(guildId, userId, record) {
  const data = read();
  const g = getGuild(data, guildId);
  g.invites[userId] = record;
  write(data);
  return record;
}

function addInvite(guildId, userId, delta = 1) {
  const rec = getInvites(guildId, userId);
  rec.joins = (rec.joins || 0) + (delta > 0 ? delta : 0);
  rec.leaves = (rec.leaves || 0) + (delta < 0 ? Math.abs(delta) : 0);
  rec.total = (rec.joins || 0) - (rec.leaves || 0) + (rec.bonus || 0);
  return setInvites(guildId, userId, rec);
}

function addBonus(guildId, userId, amount) {
  const rec = getInvites(guildId, userId);
  rec.bonus = (rec.bonus || 0) + amount;
  rec.total = (rec.joins || 0) - (rec.leaves || 0) + (rec.bonus || 0);
  return setInvites(guildId, userId, rec);
}

function getRewards(guildId) {
  const data = read();
  const g = getGuild(data, guildId);
  return g.rewards || {};
}

function setReward(guildId, invitesRequired, roleId) {
  const data = read();
  const g = getGuild(data, guildId);
  g.rewards[String(invitesRequired)] = roleId;
  write(data);
  return g.rewards;
}

function removeReward(guildId, invitesRequired) {
  const data = read();
  const g = getGuild(data, guildId);
  delete g.rewards[String(invitesRequired)];
  write(data);
  return g.rewards;
}

function getAnnounce(guildId) {
  const data = read();
  const g = getGuild(data, guildId);
  return g.announce || { channelId: null, message: null };
}

function setAnnounce(guildId, channelId, message) {
  const data = read();
  const g = getGuild(data, guildId);
  g.announce = { channelId, message: message || null };
  write(data);
  return g.announce;
}

function clearAnnounce(guildId) {
  const data = read();
  const g = getGuild(data, guildId);
  g.announce = { channelId: null, message: null };
  write(data);
  return g.announce;
}

function recordJoin(guildId, memberId, inviterId) {
  const data = read();
  const g = getGuild(data, guildId);
  g.logs[memberId] = { inviterId, at: Date.now() };
  write(data);
}

function getJoinLog(guildId, memberId) {
  const data = read();
  const g = getGuild(data, guildId);
  return g.logs[memberId] || null;
}

module.exports = {
  read,
  write,
  getInvites,
  addInvite,
  addBonus,
  getRewards,
  setReward,
  removeReward,
  recordJoin,
  getJoinLog,
  getAnnounce,
  setAnnounce,
  clearAnnounce,
};
