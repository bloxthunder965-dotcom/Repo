#!/bin/sh
while true; do
  echo "[watchdog] starting bot at $(date)"
  NODE_OPTIONS="--dns-result-order=ipv4first" npm start
  echo "[watchdog] bot exited with code $? at $(date), restarting in 5s..."
  sleep 5
done
