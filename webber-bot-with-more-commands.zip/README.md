# clipsieXD Discord Bot

A Discord bot (discord.js v14) with **invite tracking + role rewards** and **moderation** slash commands.

## Features

### Invite rewards
- Tracks who invited new members (by comparing invite use counts).
- Stores invite totals per user (`joins - leaves + bonus`).
- Configurable role rewards: when a member reaches N invites, they get a role (and lose it if they drop below, e.g. via bonus adjustment).
- Commands:
  - `/invites [user]` — show invite stats
  - `/invitereward add invites:<n> role:<role>` — set a role reward threshold (Manage Server)
  - `/invitereward remove invites:<n>` — remove a threshold (Manage Server)
  - `/invitereward list` — list configured rewards
  - `/invitebonus user:<user> amount:<n>` — add/remove bonus invites (Manage Server)
  - `/inviteleaderboard` — top inviters

### Moderation
- `/kick`, `/ban`, `/unban`
- `/softban` — ban to delete the last 7 days of messages, then unban
- `/timeout`, `/untimeout`
- `/purge` (bulk delete, up to 100, <14 days old)
- `/slowmode`
- `/lock`, `/unlock`, `/nick`
- `/warn <user> <reason> [dm:false]` — warn a member (optionally DM them)
- `/warnings <user>` — list a member's warnings
- `/clearwarnings <user> [index] [all:true]` — remove one or all warnings

### Utility
- `/help`, `/ping`, `/serverinfo`, `/userinfo`, `/avatar`
- `/botinfo` — uptime, ping, server/user counts, library version
- `/roleinfo <role>` — role details, color, members, permissions
- `/channelinfo [channel]` — channel details, slowmode, topic
- `/membercount` — humans / bots / total breakdown
- `/snowflake <id>` — see when any Discord ID was created
- `/embed <title> <description> [color] [footer] [channel]` — send an embed
- `/announce <message> [title] [channel]` — post an announcement embed
- `/poll <question> <option1> <option2> [option3] [option4] [channel]` — reaction poll

### Fun
- `/roll [dice]` — e.g. `1d20`, `2d6`, `d100`
- `/choose <options>` — pick randomly from a comma-separated list
- `/coinflip [flips]`, `/8ball <question>`, `/rps <choice>`, `/reverse <text>`

> New commands are loaded automatically, but you must run `npm run deploy` once so Discord knows about them.

## Setup

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Create `.env`** (you can copy `.env.example`)
   ```env
   DISCORD_TOKEN=your_bot_token_here
   CLIENT_ID=your_application_client_id_here
   # Optional: deploy commands to one guild instantly during testing
   # GUILD_ID=your_guild_id_here
   ```

3. **Discord Developer Portal**
   - Create an application/bot and copy the **Bot Token** and **Application (Client) ID**.
   - Enable privileged intents: **Server Members Intent** (required for join tracking & member fetch). Message Content is enabled in code but not required for these slash commands.
   - Bot permissions needed: Manage Roles, Kick Members, Ban Members, Moderate Members, Manage Messages, Manage Channels, plus basic view/send. For invite rewards, the bot’s highest role must be **above** any reward roles it assigns.
   - OAuth2 invite scopes: `bot applications.commands`.

4. **Deploy slash commands**
   ```bash
   npm run deploy
   ```
   - With `GUILD_ID` set: instant in that server.
   - Without it: global deploy can take up to ~1 hour to propagate.

5. **Run the bot**
   ```bash
   npm start
   ```

## Notes & limitations
- Invite tracking relies on Discord's invite `uses` counter. It works when the bot is online and has **Manage Server** permission to view invites. Invites created/used while the bot is offline may not be attributed.
- If a member joins via vanity URL or an untracked source, no inviter is credited.
- Data is stored in `data/db.json` (invite rewards) and `data/warns.json` (warnings). Back them up if needed.
- The bot will try to add/remove reward roles when counts change (join or `/invitebonus`) and when it can fetch the inviter/member; ensure role hierarchy allows it.
- `/poll` and `/embed` need **Send Messages** + **Add Reactions** (for polls) in the target channel.

